/*
 * Dax Henson
 * 05-03-18
 * TechShell.c
 *
 * A new shell because there aren't enough shells in the world
 *
 */

/*
 * I started work on set, but it is not finished or implemented,
 * and I have not worked on list.
 * However, simple unix commands and built-ins still work, as
 * as does piping, I/O redirection, and error conditions
 */
